# Medical Report Explainer 🩺

This is a simple API + frontend application that explains complex medical reports in plain English using OpenAI's GPT model.

## 🔧 How to Run

1. **Install requirements**:
   ```bash
   pip install flask openai
   ```

2. **Set your OpenAI key**:
   ```bash
   export OPENAI_API_KEY="your-api-key"
   ```

3. **Run the app**:
   ```bash
   python app.py
   ```

4. **Use**: Open your browser at [http://localhost:5000](http://localhost:5000) and paste a medical report to get a simple explanation.

## 📁 Files

- `app.py` — main app (API + frontend in one)
- `README.md` — documentation

## ✅ Ready for GitHub / VCS

You can push this folder as-is to GitHub or use it in VS Code.

