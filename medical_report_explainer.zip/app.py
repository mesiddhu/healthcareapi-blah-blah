from flask import Flask, request, render_template_string
import openai
import os

app = Flask(__name__)

openai.api_key = os.getenv("OPENAI_API_KEY", "your-api-key-here")

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Medical Report Explainer</title>
</head>
<body style="font-family: Arial; margin: 50px;">
    <h1>Medical Report Explainer 🩺</h1>
    <form method="POST">
        <textarea name="input_text" rows="10" cols="80" placeholder="Paste your medical report or result here..." required></textarea><br><br>
        <button type="submit">Explain in Simple Terms</button>
    </form>
    {% if result %}
        <h2>🧾 Explanation:</h2>
        <p>{{ result }}</p>
    {% endif %}
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    if request.method == "POST":
        user_input = request.form["input_text"]
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful medical assistant that explains medical results in layman's terms."},
                    {"role": "user", "content": f"Explain this medical text simply: {user_input}"}
                ],
                temperature=0.5
            )
            result = response.choices[0].message["content"]
        except Exception as e:
            result = f"Error: {str(e)}"
    return render_template_string(HTML_TEMPLATE, result=result)

if __name__ == "__main__":
    app.run(debug=True)
